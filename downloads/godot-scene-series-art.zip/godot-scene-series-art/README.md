# Godot Scene Series art pack

Every picture from the videos and starter projects, as PNG files.
Everything is **16 x 16**:
- characters, enemies, pickups and hazards stand on the bottom row of a 16 x 16 canvas (round things sit in the middle);
- tiles are 16 x 16 and repeat seamlessly.

Draw your own on a 16 x 16 canvas and it will drop straight into the starter projects.
The easiest swap: save your PNG with the same name over the old one inside the project's `assets` folder.
