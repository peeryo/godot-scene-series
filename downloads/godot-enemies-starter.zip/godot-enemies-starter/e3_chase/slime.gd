extends CharacterBody2D
## E3 Slime: the sprite and body shape are done. Watch the E3 video, then:
##   1. Add an Area2D child to Slime and name it DetectionArea.
##   2. Give DetectionArea its own CollisionShape2D -> New CircleShape2D (Radius 48).
##   3. DetectionArea > Node tab > Signals: connect body_entered AND body_exited to Slime (this script).
##   4. Fill in the TODOs.

const SPEED := 30.0

# TODO 1: a variable for who the slime is chasing. It starts empty:
#         var target: Node2D = null


func _physics_process(_delta: float) -> void:
	# TODO 2: if there is a target, move toward it. Otherwise stand still.
	#         (Hint: global_position.direction_to(target.global_position) * SPEED)
	move_and_slide()


# TODO 3: in the body_entered function: if the body is in the "player" group, make it the target.
# TODO 4: in the body_exited function: if the body is the target, clear the target (null).
