extends Area2D
## E2 Spikes.tscn: danger can be an Area2D. Watch the E2 video, then:
##   1. Add these children to Spikes:
##        Sprite2D          -> Texture: res://assets/things/spikes.png
##        CollisionShape2D  -> Shape: New RectangleShape2D (Size 16 x 6), Position y = 5
##   2. Select Spikes. In the Inspector, open Collision:
##        Layer: turn OFF 1, turn ON 3.     Mask: turn everything OFF.
##   No code needed here. The player's Hurtbox does the noticing.
