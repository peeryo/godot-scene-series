extends CanvasLayer
## Finished for you: three hearts that follow the player's health_changed signal.


func _ready() -> void:
	show_hearts(3)


func show_hearts(n: int) -> void:
	var i := 0
	for heart in $Hearts.get_children():
		(heart as CanvasItem).modulate.a = 1.0 if i < n else 0.25
		i += 1


func _on_player_health_changed(new_health: int) -> void:
	show_hearts(new_health)
