extends CharacterBody2D
## E2 player: moving, health and the HUD are finished. Watch the E2 video, then:
##   1. Add an Area2D child to Player and name it Hurtbox.
##   2. Give Hurtbox its own CollisionShape2D -> New RectangleShape2D (Size 10 x 14).
##   3. Select Hurtbox. In the Inspector, open Collision:
##        Layer: turn everything OFF.     Mask: turn OFF 1, turn ON 3.
##   4. Hurtbox > Node tab > Signals: connect area_entered to Player (this script).
##   5. In the new function, replace pass with:
##        health -= 1
##        health_changed.emit(health)
##        velocity.y = -200

signal health_changed(new_health: int)

var health := 3

const SPEED := 90.0
const JUMP_VELOCITY := -230.0


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	var dir := Input.get_axis("move_left", "move_right")
	velocity.x = dir * SPEED
	move_and_slide()
	update_animation(dir)


func update_animation(dir: float) -> void:
	var sprite := $AnimatedSprite2D as AnimatedSprite2D
	if dir != 0.0:
		sprite.flip_h = dir < 0.0
	if not is_on_floor():
		sprite.play("jump")
	elif dir != 0.0:
		sprite.play("run")
	else:
		sprite.play("idle")
