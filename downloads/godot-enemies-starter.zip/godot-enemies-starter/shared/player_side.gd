extends CharacterBody2D
## Finished for you: the platformer player from P1. It is in the "player" group.

const SPEED := 90.0
const JUMP_VELOCITY := -230.0


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	var dir := Input.get_axis("move_left", "move_right")
	velocity.x = dir * SPEED
	move_and_slide()
	update_animation(dir)


func update_animation(dir: float) -> void:
	var sprite := $AnimatedSprite2D as AnimatedSprite2D
	if dir != 0.0:
		sprite.flip_h = dir < 0.0
	if not is_on_floor():
		sprite.play("jump")
	elif dir != 0.0:
		sprite.play("run")
	else:
		sprite.play("idle")
