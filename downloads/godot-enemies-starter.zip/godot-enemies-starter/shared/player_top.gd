extends CharacterBody2D
## Finished for you: the top-down player from P2. It is in the "player" group.

const SPEED := 70.0

var facing := "down"


func _physics_process(_delta: float) -> void:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	velocity = dir * SPEED
	move_and_slide()
	update_animation(dir)


func update_animation(dir: Vector2) -> void:
	var sprite := $AnimatedSprite2D as AnimatedSprite2D
	if dir != Vector2.ZERO:
		if absf(dir.x) > absf(dir.y):
			facing = "side"
			sprite.flip_h = dir.x < 0.0
		else:
			facing = "down" if dir.y > 0.0 else "up"
		sprite.play("walk_" + facing)
	else:
		sprite.play("idle_" + facing)
