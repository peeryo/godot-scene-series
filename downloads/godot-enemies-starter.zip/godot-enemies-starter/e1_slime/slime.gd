extends CharacterBody2D
## E1 Slime.tscn: an enemy is a body too. Watch the E1 video, then:
##   1. Add these children to Slime:
##        AnimatedSprite2D  -> Sprite Frames: res://assets/frames/slime.tres
##                             (in the SpriteFrames panel, press "Autoplay on Load")
##        CollisionShape2D  -> Shape: New RectangleShape2D (Size 12 x 8), Position y = 4
##   2. Fill in TODO 1 and 2 and press play: it walks and turns at the block.
##   3. Then add a RayCast2D child: Target Position (0, 12), Position (6, 4). Do TODO 3.

const SPEED := 25.0

var dir := -1.0


func _physics_process(delta: float) -> void:
	velocity += get_gravity() * delta

	# TODO 1: set velocity.x using dir and SPEED.

	move_and_slide()

	# TODO 2: if the slime is touching a wall (is_on_wall()), flip dir.

	# TODO 3 (after you add the RayCast2D): move the ray ahead of the slime and turn at ledges.
	#         (Hint: first check $RayCast2D.is_colliding() and flip dir if there's no floor,
	#          then move the ray: $RayCast2D.position.x = 6.0 * dir)

	update_sprite()


## Already done: the slime faces the way it walks.
func update_sprite() -> void:
	var sprite := get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	if sprite:
		sprite.flip_h = dir < 0.0
