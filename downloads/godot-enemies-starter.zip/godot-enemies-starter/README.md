# Godot Scene Series: Enemies starter

A Godot 4.6 project to build along with the Enemies videos (E1, E2, E3).
The player is already finished, so you can focus on the enemies and hazards.

## Open it
1. Unzip this folder.
2. In the Godot Project Manager, click **Import** and choose `project.godot` in this folder.
3. Press **F5** to run. The episode menu opens.

## How each episode works
Each episode has its own folder (`e1_slime`, `e2_hazards`, `e3_chase`). Inside:
- the **level** is finished: ground, walls, and the player;
- the scene the video builds starts small, with its script attached;
- the script's comments list which child nodes to add, which settings to change and which signals to connect,
  and the `TODO` lines are the code from the video.

Then run the project (F5) and choose the episode, or open the level and press F6.
Press **Esc** in any level to go back to the menu.

## Controls (already in the Input Map)
- `move_left` / `move_right` / `move_up` / `move_down`: arrow keys or WASD
- `jump`: Space

## The art
Every sprite here is the same pixel art as the videos, in `assets/`.
`assets/frames/hero_side.tres` and `assets/frames/hero_top.tres` are ready-made SpriteFrames:
pick one in an AnimatedSprite2D's **Sprite Frames** slot.

## Make your own art (it's all 16 x 16)
Every picture in this project is the same size, so yours can drop right in:
- **Characters, enemies, pickups and hazards:** draw on a **16 x 16** canvas. Characters stand on the bottom row; round things sit in the middle.
- **Tiles:** **16 x 16**, drawn so the edges line up when they repeat.
- Save as PNG. The game draws everything at 320 x 180 and scales it up evenly, so a 16 x 16 picture never needs the Scale setting.

The easiest swap: save your PNG **with the same name over the old one** (for example `assets/things/coin.png`).
Every scene that uses it updates at once. To replace the hero, draw each frame (`idle_0.png`, `run_0.png` ...) and save over those.

Out in the wild, game art comes in many sizes (16, 32, 48 pixels, and more), and you'd adjust collision shapes or scale to make pieces fit.
Here everything is 16 x 16 on purpose, so swapping in your own art is one less thing to figure out.
