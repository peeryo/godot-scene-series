extends Control
## Finished for you: the episode menu. Each button opens that episode's level.

const EPISODES := [
	["E1  A patrolling slime", "res://e1_slime/level.tscn"],
	["E2  Danger zones and hurtboxes", "res://e2_hazards/level.tscn"],
	["E3  Chase when close", "res://e3_chase/level.tscn"],
]


func _ready() -> void:
	var box := VBoxContainer.new()
	box.position = Vector2(20, 8)
	box.add_theme_constant_override("separation", 3)
	add_child(box)

	var title := Label.new()
	title.text = "Godot Scene Series: Enemies"
	title.add_theme_font_size_override("font_size", 11)
	box.add_child(title)

	var note := Label.new()
	note.text = "Watch an episode, open its folder in the FileSystem dock, build the scene the video shows, then press a button here to test it. The player is already finished for you.\nIn any level, press Esc to come back to this menu."
	note.add_theme_font_size_override("font_size", 5)
	note.modulate = Color(1, 1, 1, 0.75)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(280, 0)
	box.add_child(note)

	for ep in EPISODES:
		var button := Button.new()
		button.text = ep[0]
		button.custom_minimum_size = Vector2(280, 13)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_font_size_override("font_size", 6)
		# Buttons made in code are connected in code. The inspector can't see them yet.
		button.pressed.connect(get_tree().change_scene_to_file.bind(ep[1]))
		box.add_child(button)
