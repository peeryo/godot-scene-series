extends Area2D
## K1 Coin.tscn: the coin handles itself. Watch the K1 video, then:
##   1. Add these children to Coin:
##        AnimatedSprite2D  -> Sprite Frames: res://assets/frames/coin.tres
##                             (in the SpriteFrames panel, press "Autoplay on Load" so it spins)
##        CollisionShape2D  -> Shape: New CircleShape2D (Radius 3)
##   2. Select Coin, open the Node tab > Signals, and connect body_entered to this script.
##      Godot writes the new function for you, ending in pass.
##   3. Replace that pass with:
##        if body.is_in_group("player"):
##            queue_free()
