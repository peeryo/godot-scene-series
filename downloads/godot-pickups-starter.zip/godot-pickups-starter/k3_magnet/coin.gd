extends Area2D
## K3 coin: it already collects itself (see _on_body_entered). Your job is TODO 1 and 2.

# TODO 1: a variable to remember who is pulling this coin. It starts empty:
#         var target: Node2D = null


func _process(delta: float) -> void:
	# TODO 2: if target is set, slide toward it a little each frame:
	#         if target:
	#             global_position = global_position.move_toward(target.global_position, 100 * delta)
	pass


## Already done: the coin still collects itself when the player touches it.
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		queue_free()
