extends CharacterBody2D
## K3 player: moving is finished. Watch the K3 video, then:
##   1. Add an Area2D child to Player and name it MagnetArea.
##   2. Give MagnetArea its own CollisionShape2D child -> New CircleShape2D (Radius 48), far bigger than the body.
##   3. Select MagnetArea, Node tab > Signals, and connect area_entered to Player (this script).
##   4. In the new function, replace pass with:
##        if area.is_in_group("coins"):
##            area.target = self

const SPEED := 70.0

var facing := "down"


func _physics_process(_delta: float) -> void:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	velocity = dir * SPEED
	move_and_slide()
	update_animation(dir)


func update_animation(dir: Vector2) -> void:
	var sprite := $AnimatedSprite2D as AnimatedSprite2D
	if dir != Vector2.ZERO:
		if absf(dir.x) > absf(dir.y):
			facing = "side"
			sprite.flip_h = dir.x < 0.0
		else:
			facing = "down" if dir.y > 0.0 else "up"
		sprite.play("walk_" + facing)
	else:
		sprite.play("idle_" + facing)
