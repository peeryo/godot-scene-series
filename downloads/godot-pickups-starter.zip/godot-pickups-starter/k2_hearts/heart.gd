extends Area2D
## K2 Heart.tscn: built just like the coin. Watch the K2 video, then:
##   1. Add these children to Heart:
##        Sprite2D          -> Texture: res://assets/things/heart.png
##        CollisionShape2D  -> Shape: New CircleShape2D (Radius 4)
##   2. Node tab > Signals: connect body_entered to this script.
##   3. In the new function, replace pass with:
##        if body.has_method("heal"):
##            body.heal(1)
##            queue_free()
