extends CharacterBody2D
## K2 player: moving is finished. Your job is the health part (TODO 1 and 2).

# TODO 1: declare a signal called health_changed that sends one value:
#         signal health_changed(new_health: int)

var health := 1

const SPEED := 70.0

var facing := "down"


func _physics_process(_delta: float) -> void:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	velocity = dir * SPEED
	move_and_slide()
	update_animation(dir)


func update_animation(dir: Vector2) -> void:
	var sprite := $AnimatedSprite2D as AnimatedSprite2D
	if dir != Vector2.ZERO:
		if absf(dir.x) > absf(dir.y):
			facing = "side"
			sprite.flip_h = dir.x < 0.0
		else:
			facing = "down" if dir.y > 0.0 else "up"
		sprite.play("walk_" + facing)
	else:
		sprite.play("idle_" + facing)


# TODO 2: finish heal(). Add amount to health, then emit the signal:
#         health += amount
#         health_changed.emit(health)
func heal(amount: int) -> void:
	pass
