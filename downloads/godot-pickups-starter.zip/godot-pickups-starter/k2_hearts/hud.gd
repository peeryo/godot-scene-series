extends CanvasLayer
## The HUD: three hearts in the corner. show_hearts() is finished for you.
## Your job, in level.tscn:
##   1. Select Player, open the Node tab > Signals, and connect health_changed to HUD.
##      Godot writes _on_player_health_changed(new_health) at the bottom of this script.
##   2. Replace its pass with:  show_hearts(new_health)


func _ready() -> void:
	show_hearts(1)


## Already done: full hearts for n, faded hearts for the rest.
func show_hearts(n: int) -> void:
	var i := 0
	for heart in $Hearts.get_children():
		(heart as CanvasItem).modulate.a = 1.0 if i < n else 0.25
		i += 1
