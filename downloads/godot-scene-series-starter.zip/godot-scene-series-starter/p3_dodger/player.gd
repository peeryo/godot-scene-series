extends Area2D
## P3 Arcade dodger player. Watch the P3 video, then:
##   1. Add these children to Player:
##        AnimatedSprite2D  -> Sprite Frames: res://assets/frames/hero_top.tres
##        CollisionShape2D  -> Shape: New CapsuleShape2D covering the body (Radius 5, Height 14)
##   2. Fill in the TODO lines below (delete the word pass when you start).
##   3. Connect body_entered (Node tab > Signals) and finish TODO 4.

signal hit

const SPEED := 100.0

var screen_size: Vector2


func _ready() -> void:
	screen_size = get_viewport_rect().size


func _process(delta: float) -> void:
	# TODO 1: read the four move actions into a new variable called dir.
	#         (Hint: Input.get_vector with "move_left", "move_right", "move_up", "move_down")

	# TODO 2: change position using dir, SPEED and delta.

	# TODO 3: keep the player on screen.
	#         (Hint: position.clamp(Vector2.ZERO, screen_size))
	pass


# TODO 4: after you connect body_entered, put these three lines in the new function:
#   hide()
#   hit.emit()
#   $CollisionShape2D.set_deferred("disabled", true)


## Already done: the arena calls this to start a new round after a hit.
func start(pos: Vector2) -> void:
	position = pos
	show()
	var shape := get_node_or_null("CollisionShape2D") as CollisionShape2D
	if shape:
		shape.disabled = false
