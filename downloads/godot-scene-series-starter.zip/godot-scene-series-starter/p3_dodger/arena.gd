extends Node2D
## Finished for you: rolls hazards across the arena and starts a new round after a hit.

const HAZARD := preload("res://p3_dodger/hazard.tscn")

var rng := RandomNumberGenerator.new()

@onready var player: Area2D = $Player


func _ready() -> void:
	var timer := Timer.new()
	timer.wait_time = 0.8
	timer.autostart = true
	add_child(timer)
	timer.timeout.connect(_spawn_hazard)
	# The player's hit signal exists as soon as the script is attached.
	player.connect("hit", _on_player_hit)


func _spawn_hazard() -> void:
	var hazard := HAZARD.instantiate() as RigidBody2D
	var size := get_viewport_rect().size
	var from_left := rng.randf() < 0.5
	var speed := rng.randf_range(45.0, 80.0)
	hazard.position = Vector2(-12.0 if from_left else size.x + 12.0, rng.randf_range(20.0, size.y - 10.0))
	hazard.linear_velocity = Vector2(speed if from_left else -speed, rng.randf_range(-10.0, 10.0))
	hazard.angular_velocity = 5.0 if from_left else -5.0
	add_child(hazard)


func _on_player_hit() -> void:
	await get_tree().create_timer(1.5).timeout
	player.call("start", get_viewport_rect().size / 2.0)
