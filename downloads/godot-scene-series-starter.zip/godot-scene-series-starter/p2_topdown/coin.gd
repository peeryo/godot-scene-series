extends Area2D
## Coin.tscn: the coin handles itself. Watch the coin part of the P2 video, then:
##   1. Add these children to Coin:
##        Sprite2D          -> Texture: res://assets/things/coin.png
##        CollisionShape2D  -> Shape: New CircleShape2D (Radius 3)
##   2. Select Coin, open the Node tab > Signals, and connect body_entered to this script.
##      Godot writes the new function for you, ending in pass.
##   3. Replace that pass with:  queue_free()
