extends CharacterBody2D
## P2 Top-down player. Watch the P2 video, then:
##   1. Select Player and, in the Inspector, set Motion Mode to Floating.
##   2. Add these children to Player:
##        AnimatedSprite2D  -> Sprite Frames: res://assets/frames/hero_top.tres
##        CollisionShape2D  -> Shape: New CircleShape2D (Radius 3), moved down to the feet (Position y = 5)
##        Camera2D
##   3. Fill in the TODO lines below (delete the word pass when you start).

const SPEED := 70.0

var facing := "down"


func _physics_process(_delta: float) -> void:
	# TODO 1: read the four move actions into a new variable called dir.
	#         (Hint: Input.get_vector with "move_left", "move_right", "move_up", "move_down")

	# TODO 2: set velocity using dir and SPEED.

	# TODO 3: call move_and_slide().

	# TODO 4: call update_animation(dir).
	pass


## Already done: picks walk_down, walk_up or walk_side (flipped for left), or the idle frame.
func update_animation(dir: Vector2) -> void:
	var sprite := get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	if sprite == null:
		return
	if dir != Vector2.ZERO:
		if absf(dir.x) > absf(dir.y):
			facing = "side"
			sprite.flip_h = dir.x < 0.0
		else:
			facing = "down" if dir.y > 0.0 else "up"
		sprite.play("walk_" + facing)
	else:
		sprite.play("idle_" + facing)
