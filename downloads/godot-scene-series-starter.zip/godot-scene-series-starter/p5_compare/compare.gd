extends Node2D
## Finished for you: puts YOUR P2, P3 and P4 players in three lanes in front of one wall.
## Press right and watch: one walks through, one stops, one bounces.

@onready var wall: StaticBody2D = $Wall


func _ready() -> void:
	# The wall goes on collision layer 2. The two bodies look at layer 2, so they hit it.
	# The Area2D player does not, so it walks through without its hit code hiding it.
	wall.collision_layer = 2
	($CharacterLane as CollisionObject2D).set_collision_mask_value(2, true)
	($RigidLane as CollisionObject2D).set_collision_mask_value(2, true)
	# Your players may have their own cameras. Use this level's camera instead.
	var my_camera := $Camera2D as Camera2D
	for cam in find_children("*", "Camera2D", true, false):
		if cam != my_camera:
			(cam as Camera2D).enabled = false
	my_camera.make_current()
