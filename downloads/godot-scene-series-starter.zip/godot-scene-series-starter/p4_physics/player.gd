extends RigidBody2D
## P4 Physics player. Watch the P4 video, then:
##   1. Add these children to Player:
##        Sprite2D          -> Texture: res://assets/things/ball.png
##        CollisionShape2D  -> Shape: New CircleShape2D, Radius 5
##   2. Try Gravity Scale in the Inspector: 0 floats, 1 falls.
##   3. Fill in the TODO lines below (delete the word pass when you start).

const FORCE := 300.0
const JUMP := 160.0


func _physics_process(_delta: float) -> void:
	# TODO 1: read left/right input into a new variable called dir.
	#         (Hint: Input.get_axis with "move_left" and "move_right")

	# TODO 2: push the ball with apply_central_force, using dir and FORCE.

	# TODO 3: when "jump" is just pressed, kick it up with apply_central_impulse(Vector2.UP * JUMP).
	pass
