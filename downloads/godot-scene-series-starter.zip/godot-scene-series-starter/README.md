# Godot Scene Series: starter project

A Godot 4.6 project to build along with the Players videos.

## Open it
1. Unzip this folder.
2. In the Godot Project Manager, click **Import** and choose `project.godot` in this folder.
3. Press **F5** to run. The episode menu opens.

## How each episode works
Each episode has its own folder (`p1_platformer`, `p2_topdown`, ...). Inside:
- the **level** is finished: ground, walls and things to bump into;
- `player.tscn` has only its **root node**, with its script already attached;
- `player.gd` is partly written. The comments at the top list which child nodes to add,
  and the `TODO` lines are the code from the video.

Open `player.tscn`, add the child nodes the video shows, open `player.gd` and fill in the TODOs.
Then run the project (F5) and choose the episode, or open the level and press F6.
Press **Esc** in any level to go back to the menu.

P5 has nothing to build: it drops your P2, P3 and P4 players side by side in front of one wall.

## Controls (already in the Input Map)
- `move_left` / `move_right` / `move_up` / `move_down`: arrow keys or WASD
- `jump`: Space

## The art
Every sprite here is the same pixel art as the videos, in `assets/`.
`assets/frames/hero_side.tres` and `assets/frames/hero_top.tres` are ready-made SpriteFrames:
pick one in an AnimatedSprite2D's **Sprite Frames** slot.

## Make your own art (it's all 16 x 16)
Every picture in this project is the same size, so yours can drop right in:
- **Characters, enemies, pickups and hazards:** draw on a **16 x 16** canvas. Characters stand on the bottom row; round things sit in the middle.
- **Tiles:** **16 x 16**, drawn so the edges line up when they repeat.
- Save as PNG. The game draws everything at 320 x 180 and scales it up evenly, so a 16 x 16 picture never needs the Scale setting.

The easiest swap: save your PNG **with the same name over the old one** (for example `assets/things/coin.png`).
Every scene that uses it updates at once. To replace the hero, draw each frame (`idle_0.png`, `run_0.png` ...) and save over those.

Out in the wild, game art comes in many sizes (16, 32, 48 pixels, and more), and you'd adjust collision shapes or scale to make pieces fit.
Here everything is 16 x 16 on purpose, so swapping in your own art is one less thing to figure out.
