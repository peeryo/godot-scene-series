extends CharacterBody2D
## P1 Platformer player. Watch the P1 video, then:
##   1. Add these children to Player (right-click Player > Add Child Node):
##        AnimatedSprite2D  -> Sprite Frames: res://assets/frames/hero_side.tres
##        CollisionShape2D  -> Shape: New CapsuleShape2D (Radius 5, Height 16)
##        Camera2D
##   2. Fill in the TODO lines below.
##   3. Press Esc or open the menu and choose P1 to test it.

const SPEED := 90.0
const JUMP_VELOCITY := -230.0


func _physics_process(delta: float) -> void:
	# Already done: fall while in the air.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Already done: jump when Space is pressed on the ground.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# TODO 1: read left/right input into a new variable called dir.
	#         (Hint: Input.get_axis with "move_left" and "move_right")

	# TODO 2: set velocity.x using dir and SPEED.

	move_and_slide()

	# TODO 3: call update_animation(dir) so the sprite runs, jumps and turns.


## Already done: picks idle, run or jump, and faces the way you move.
func update_animation(dir: float) -> void:
	var sprite := get_node_or_null("AnimatedSprite2D") as AnimatedSprite2D
	if sprite == null:
		return
	if dir != 0.0:
		sprite.flip_h = dir < 0.0
	if not is_on_floor():
		sprite.play("jump")
	elif dir != 0.0:
		sprite.play("run")
	else:
		sprite.play("idle")
