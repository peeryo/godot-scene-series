extends Node
## Finished for you: press Esc in any level to go back to the episode menu.

const MENU := "res://start_here.tscn"


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		var current := get_tree().current_scene
		if current and current.scene_file_path != MENU:
			get_tree().change_scene_to_file(MENU)
